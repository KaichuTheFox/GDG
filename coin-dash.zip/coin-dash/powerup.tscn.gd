extends Area2D


var screensize = Vector2.ZERO

func pickup():
	queue_free()


func _on_lifetime_timeout() -> void:
	queue_free()
