# Z Language Compiler 0.2.0

Windows-first C++17 compiler for Z. The compiler performs lexing, parsing, AST construction,
semantic analysis, C++17 generation, and MSVC/Clang/MinGW native compilation. Python is not used.

## Easiest Windows workflow

Requirements: Visual Studio 2022 with **Desktop development with C++** and **C++ CMake tools for Windows**.

1. Double-click `BUILD_WINDOWS.bat` once.
2. Compile: `ZBUILD.bat main.z`
3. Compile and run: `ZRUN.bat main.z`
4. Run every automated Windows check: `AUTO_CHECK_WINDOWS.bat`

The compiler itself is generated at `build\windows-x64\bin\zlang.exe`.

Direct usage:

```powershell
.\build\windows-x64\bin\zlang.exe main.z
.\build\windows-x64\bin\zlang.exe run main.z
.\build\windows-x64\bin\zlang.exe main.z -o hello.exe
```

A normal Visual Studio Developer PowerShell automatically exposes `cl.exe`. `zlang` also searches
`ZLANG_CXX`, `CXX`, `cl.exe`, `clang++.exe`, and `g++.exe` in that order.

## Automated Windows verification

```powershell
.\AUTO_CHECK_WINDOWS.ps1 -Architecture x64
```

The script configures and builds with MSVC, checks the CLI, runs CTest, creates and executes real
Windows EXEs, checks expected output, tests compiler diagnostics, and verifies stale-output safety.

## Important fixes in this edition

- Every source file is normally formatted and readable.
- `cl.exe --version` is no longer used.
- `--cxx` accepts a path or executable name and validates it.
- `CreateProcessW` receives a writable command line and handles UTF-8 arguments.
- `>=` is recognized as a boolean comparison.
- Lexer and parser failures stop later stages.
- Temporary C++ and EXE names are unique.
- Native compilation writes a temporary EXE, then atomically replaces the requested output.
- `hello.z` really prints `Hello World!`; arithmetic has a separate example.
- Windows integration tests use `.exe` paths and the active CMake compiler.

## Scope

This MVP supports `box`, `line`, `bool`, `cpx`, declarations, assignment, print, arithmetic,
comparison, if/else-if/else, while, range-for, functions, return, calls, comments, semicolons,
newlines, and UTF-8 string literals. LLVM, classes, arrays, modules, and direct PE generation are
future work.
