#include "zlang/Process.h"

#include <cstdlib>
#include <sstream>

#ifdef _WIN32
#include <windows.h>
#else
#include <sys/wait.h>
#endif

namespace zlang {
namespace {

#ifdef _WIN32
std::wstring quoteWindowsArgument(const std::wstring& argument)
{
    if (argument.empty()) {
        return L"\"\"";
    }
    if (argument.find_first_of(L" \t\"") == std::wstring::npos) {
        return argument;
    }

    std::wstring result = L"\"";
    std::size_t backslashes = 0;
    for (const wchar_t character : argument) {
        if (character == L'\\') {
            ++backslashes;
        } else if (character == L'"') {
            result.append(backslashes * 2 + 1, L'\\');
            result.push_back(L'"');
            backslashes = 0;
        } else {
            result.append(backslashes, L'\\');
            backslashes = 0;
            result.push_back(character);
        }
    }
    result.append(backslashes * 2, L'\\');
    result.push_back(L'"');
    return result;
}

std::wstring utf8ToWide(const std::string& text)
{
    if (text.empty()) {
        return {};
    }
    const int size = MultiByteToWideChar(CP_UTF8,
                                         MB_ERR_INVALID_CHARS,
                                         text.data(),
                                         static_cast<int>(text.size()),
                                         nullptr,
                                         0);
    if (size <= 0) {
        return std::wstring(text.begin(), text.end());
    }
    std::wstring result(static_cast<std::size_t>(size), L'\0');
    MultiByteToWideChar(CP_UTF8,
                        MB_ERR_INVALID_CHARS,
                        text.data(),
                        static_cast<int>(text.size()),
                        result.data(),
                        size);
    return result;
}

std::optional<std::filesystem::path> resolveExecutable(const std::filesystem::path& executable)
{
    if (executable.has_parent_path()) {
        return std::filesystem::exists(executable) ? std::optional(executable) : std::nullopt;
    }

    std::vector<wchar_t> buffer(32768);
    const DWORD length = SearchPathW(nullptr,
                                     executable.c_str(),
                                     nullptr,
                                     static_cast<DWORD>(buffer.size()),
                                     buffer.data(),
                                     nullptr);
    if (length == 0 || length >= buffer.size()) {
        return std::nullopt;
    }
    return std::filesystem::path(std::wstring(buffer.data(), length));
}
#else
std::string quotePosixArgument(const std::string& argument)
{
    std::string result = "'";
    for (const char character : argument) {
        result += character == '\'' ? "'\\''" : std::string(1, character);
    }
    result.push_back('\'');
    return result;
}
#endif

} // namespace

ProcessResult runProcess(const std::filesystem::path& executable,
                         const std::vector<std::string>& arguments)
{
#ifdef _WIN32
    const auto resolved = resolveExecutable(executable);
    if (!resolved) {
        return {2, executable.string(), "executable not found"};
    }

    std::wstring commandLine = quoteWindowsArgument(resolved->wstring());
    for (const auto& argument : arguments) {
        commandLine.push_back(L' ');
        commandLine += quoteWindowsArgument(utf8ToWide(argument));
    }
    std::vector<wchar_t> writable(commandLine.begin(), commandLine.end());
    writable.push_back(L'\0');

    STARTUPINFOW startup{};
    startup.cb = sizeof(startup);
    PROCESS_INFORMATION process{};
    const BOOL created = CreateProcessW(resolved->c_str(),
                                        writable.data(),
                                        nullptr,
                                        nullptr,
                                        FALSE,
                                        0,
                                        nullptr,
                                        nullptr,
                                        &startup,
                                        &process);
    if (!created) {
        return {static_cast<int>(GetLastError()), executable.string(), "CreateProcessW failed"};
    }

    WaitForSingleObject(process.hProcess, INFINITE);
    DWORD exitCode = 0;
    GetExitCodeProcess(process.hProcess, &exitCode);
    CloseHandle(process.hThread);
    CloseHandle(process.hProcess);
    return {static_cast<int>(exitCode), executable.string(), {}};
#else
    std::string command = quotePosixArgument(executable.string());
    for (const auto& argument : arguments) {
        command += ' ' + quotePosixArgument(argument);
    }
    const int result = std::system(command.c_str());
    return {WIFEXITED(result) ? WEXITSTATUS(result) : result, command, {}};
#endif
}

std::filesystem::path findCompiler(
    const std::optional<std::filesystem::path>& specifiedCompiler,
    std::vector<std::string>& triedCompilers)
{
    if (specifiedCompiler) {
        triedCompilers.push_back(specifiedCompiler->string());
#ifdef _WIN32
        const auto resolved = resolveExecutable(*specifiedCompiler);
        return resolved.value_or(std::filesystem::path{});
#else
        return *specifiedCompiler;
#endif
    }

    std::vector<std::filesystem::path> candidates;
    if (const char* configured = std::getenv("ZLANG_CXX")) {
        candidates.emplace_back(configured);
    }
    if (const char* environment = std::getenv("CXX")) {
        candidates.emplace_back(environment);
    }
#ifdef _WIN32
    candidates.emplace_back("cl.exe");
    candidates.emplace_back("clang++.exe");
    candidates.emplace_back("g++.exe");
#else
    candidates.emplace_back("clang++");
    candidates.emplace_back("g++");
    candidates.emplace_back("c++");
#endif

    for (const auto& candidate : candidates) {
        triedCompilers.push_back(candidate.string());
#ifdef _WIN32
        if (const auto resolved = resolveExecutable(candidate)) {
            return *resolved;
        }
#else
        if (runProcess(candidate, {"--version"}).exitCode == 0) {
            return candidate;
        }
#endif
    }
    return {};
}

} // namespace zlang
