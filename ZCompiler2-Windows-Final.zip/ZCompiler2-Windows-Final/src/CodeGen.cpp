#include "zlang/CodeGen.h"

#include <fstream>
#include <iomanip>
#include <sstream>

namespace zlang {

std::string CppCodeGenerator::escapeString(const std::string& value)
{
    std::ostringstream output;
    for (const unsigned char character : value) {
        switch (character) {
        case '\\': output << "\\\\"; break;
        case '"': output << "\\\""; break;
        case '\n': output << "\\n"; break;
        case '\r': output << "\\r"; break;
        case '\t': output << "\\t"; break;
        case 0: output << "\\0"; break;
        default: output << character; break;
        }
    }
    return output.str();
}

std::string CppCodeGenerator::generateExpression(const Expr& expression)
{
    if (const auto* literal = dynamic_cast<const LiteralExpr*>(&expression)) {
        if (const auto* value = std::get_if<std::int64_t>(&literal->value)) {
            return "ZValue(ZInteger{" + std::to_string(*value) + "})";
        }
        if (const auto* value = std::get_if<double>(&literal->value)) {
            std::ostringstream output;
            output << std::setprecision(17) << *value;
            return "ZValue(ZFloat{" + output.str() + "})";
        }
        if (const auto* value = std::get_if<std::string>(&literal->value)) {
            return "ZValue(ZString{\"" + escapeString(*value) + "\"})";
        }
        return std::get<bool>(literal->value) ? "ZValue(true)" : "ZValue(false)";
    }
    if (const auto* name = dynamic_cast<const NameExpr*>(&expression)) {
        return "zusr_" + name->name;
    }
    if (const auto* unary = dynamic_cast<const UnaryExpr*>(&expression)) {
        return "zUnary(\"" + unary->op + "\", " + generateExpression(*unary->rhs) + ")";
    }
    if (const auto* binary = dynamic_cast<const BinaryExpr*>(&expression)) {
        return "zBinary(\"" + binary->op + "\", " + generateExpression(*binary->lhs) +
               ", " + generateExpression(*binary->rhs) + ")";
    }
    if (const auto* call = dynamic_cast<const CallExpr*>(&expression)) {
        std::string output = call->callee == "cpx" ? "zMakeComplex(" : "zfn_" + call->callee + "(";
        for (std::size_t index = 0; index < call->args.size(); ++index) {
            if (index != 0) {
                output += ", ";
            }
            output += generateExpression(*call->args[index]);
        }
        return output + ")";
    }
    return "ZValue{}";
}

void CppCodeGenerator::generateStatement(const Stmt& statement, int indentation)
{
    const std::string indent(static_cast<std::size_t>(indentation), ' ');
    if (const auto* declaration = dynamic_cast<const VarDecl*>(&statement)) {
        output_ += indent + "ZValue zusr_" + declaration->name + " = " +
                   generateExpression(*declaration->init) + ";\n";
    } else if (const auto* assignment = dynamic_cast<const Assign*>(&statement)) {
        output_ += indent + "zusr_" + assignment->name + " = " +
                   generateExpression(*assignment->value) + ";\n";
    } else if (const auto* print = dynamic_cast<const Print*>(&statement)) {
        for (const auto& argument : print->args) {
            output_ += indent + "zPrint(" + generateExpression(*argument) + ");\n";
        }
    } else if (const auto* returnStatement = dynamic_cast<const Return*>(&statement)) {
        output_ += indent + "return " +
                   (returnStatement->value ? generateExpression(*returnStatement->value)
                                           : "ZValue{}") +
                   ";\n";
    } else if (const auto* expression = dynamic_cast<const ExprStmt*>(&statement)) {
        output_ += indent + generateExpression(*expression->expr) + ";\n";
    } else if (const auto* conditional = dynamic_cast<const If*>(&statement)) {
        output_ += indent + "if (zRequireBool(" + generateExpression(*conditional->cond) + ")) {\n";
        for (const auto& child : conditional->thenBlock->statements) {
            generateStatement(*child, indentation + 4);
        }
        output_ += indent + "}";
        for (const auto& branch : conditional->elseIfs) {
            output_ += " else if (zRequireBool(" + generateExpression(*branch.first) + ")) {\n";
            for (const auto& child : branch.second->statements) {
                generateStatement(*child, indentation + 4);
            }
            output_ += indent + "}";
        }
        if (conditional->elseBlock) {
            output_ += " else {\n";
            for (const auto& child : conditional->elseBlock->statements) {
                generateStatement(*child, indentation + 4);
            }
            output_ += indent + "}";
        }
        output_ += "\n";
    } else if (const auto* loop = dynamic_cast<const While*>(&statement)) {
        output_ += indent + "while (zRequireBool(" + generateExpression(*loop->cond) + ")) {\n";
        for (const auto& child : loop->body->statements) {
            generateStatement(*child, indentation + 4);
        }
        output_ += indent + "}\n";
    } else if (const auto* loop = dynamic_cast<const For*>(&statement)) {
        output_ += indent + "for (ZInteger zint_i = 0, zint_n = zRangeEnd(" +
                   generateExpression(*loop->end) + "); zint_i < zint_n; ++zint_i) {\n";
        output_ += indent + "    ZValue zusr_" + loop->name + " = ZValue(zint_i);\n";
        for (const auto& child : loop->body->statements) {
            generateStatement(*child, indentation + 4);
        }
        output_ += indent + "}\n";
    }
}

bool CppCodeGenerator::generate(const Program& program, const std::filesystem::path& outputPath)
{
    output_ = R"CPP(#include <cmath>
#include <complex>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>
#include <variant>
#ifdef _WIN32
#include <windows.h>
#endif

using ZInteger = std::int64_t;
using ZFloat = double;
using ZString = std::string;
using ZComplex = std::complex<double>;
using ZValue = std::variant<std::monostate, ZInteger, ZFloat, ZString, bool, ZComplex>;

static double zRequireNumber(const ZValue& value)
{
    if (const auto* integer = std::get_if<ZInteger>(&value)) return static_cast<double>(*integer);
    if (const auto* floating = std::get_if<ZFloat>(&value)) return *floating;
    throw std::runtime_error("numeric value required");
}

static bool zRequireBool(const ZValue& value)
{
    if (const auto* boolean = std::get_if<bool>(&value)) return *boolean;
    throw std::runtime_error("bool required");
}

static ZValue zMakeComplex(const ZValue& real, const ZValue& imaginary)
{
    return ZComplex(zRequireNumber(real), zRequireNumber(imaginary));
}

static ZInteger zRangeEnd(const ZValue& value)
{
    const double number = zRequireNumber(value);
    if (!std::isfinite(number) || std::floor(number) != number)
        throw std::runtime_error("range end must be an integer");
    if (number <= 0) return 0;
    if (number > static_cast<double>(std::numeric_limits<ZInteger>::max()))
        throw std::runtime_error("range end is too large");
    return static_cast<ZInteger>(number);
}

static ZValue zUnary(const std::string& op, const ZValue& value)
{
    if (op == "+") return value;
    if (const auto* integer = std::get_if<ZInteger>(&value)) {
        if (*integer == std::numeric_limits<ZInteger>::min())
            throw std::runtime_error("integer overflow");
        return -*integer;
    }
    return -zRequireNumber(value);
}

static ZValue zBinary(const std::string& op, const ZValue& left, const ZValue& right)
{
    if (op == "==") return left == right;
    if (op == "!=") return left != right;

    if (std::holds_alternative<ZComplex>(left) && std::holds_alternative<ZComplex>(right)) {
        const auto a = std::get<ZComplex>(left);
        const auto b = std::get<ZComplex>(right);
        if (op == "+") return a + b;
        if (op == "-") return a - b;
        if (op == "*") return a * b;
        if (op == "/") {
            if (b == ZComplex{}) throw std::runtime_error("division by zero");
            return a / b;
        }
    }

    if (op == "+" && std::holds_alternative<ZString>(left) &&
        std::holds_alternative<ZString>(right))
        return std::get<ZString>(left) + std::get<ZString>(right);

    const double a = zRequireNumber(left);
    const double b = zRequireNumber(right);
    if (op == "<") return a < b;
    if (op == "<=") return a <= b;
    if (op == ">") return a > b;
    if (op == ">=") return a >= b;
    if (op == "/") {
        if (b == 0.0) throw std::runtime_error("division by zero");
        return a / b;
    }

    const bool integers = std::holds_alternative<ZInteger>(left) &&
                          std::holds_alternative<ZInteger>(right);
    if (integers) {
        const ZInteger x = std::get<ZInteger>(left);
        const ZInteger y = std::get<ZInteger>(right);
        if (op == "+") return x + y;
        if (op == "-") return x - y;
        if (op == "*") return x * y;
    }
    if (op == "+") return a + b;
    if (op == "-") return a - b;
    if (op == "*") return a * b;
    throw std::runtime_error("invalid operator");
}

static std::string zText(const ZValue& value)
{
    if (const auto* integer = std::get_if<ZInteger>(&value)) return std::to_string(*integer);
    if (const auto* floating = std::get_if<ZFloat>(&value)) {
        std::ostringstream output;
        output << std::setprecision(15) << *floating;
        return output.str();
    }
    if (const auto* text = std::get_if<ZString>(&value)) return *text;
    if (const auto* boolean = std::get_if<bool>(&value)) return *boolean ? "true" : "false";
    if (const auto* valueComplex = std::get_if<ZComplex>(&value)) {
        std::ostringstream output;
        output << valueComplex->real() << (valueComplex->imag() < 0 ? "" : "+")
               << valueComplex->imag() << "i";
        return output.str();
    }
    return {};
}

static void zPrint(const ZValue& value) { std::cout << zText(value); }

)CPP";

    for (const auto& function : program.functions) {
        output_ += "static ZValue zfn_" + function->name + "(";
        for (std::size_t index = 0; index < function->params.size(); ++index) {
            if (index != 0) output_ += ", ";
            output_ += "ZValue zusr_" + function->params[index];
        }
        output_ += ");\n";
    }

    for (const auto& function : program.functions) {
        output_ += "\nstatic ZValue zfn_" + function->name + "(";
        for (std::size_t index = 0; index < function->params.size(); ++index) {
            if (index != 0) output_ += ", ";
            output_ += "ZValue zusr_" + function->params[index];
        }
        output_ += ")\n{\n";
        for (const auto& statement : function->body->statements) {
            generateStatement(*statement, 4);
        }
        output_ += "    return ZValue{};\n}\n";
    }

    output_ += R"CPP(
int main()
{
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif
    try {
        zfn_main();
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "runtime error: " << error.what() << '\n';
        return 5;
    }
}
)CPP";

    std::ofstream file(outputPath, std::ios::binary);
    file.write(output_.data(), static_cast<std::streamsize>(output_.size()));
    return static_cast<bool>(file);
}

} // namespace zlang
