# Grammar

The parser implements function declarations, lexical blocks, typed variable declarations,
statement-level assignment, print, if/else-if/else, while, `for name in +(end)`, return, calls,
and precedence levels: call, unary, multiplication, addition, comparison, equality. A newline or
semicolon terminates a statement; newlines inside parentheses are ignored.
