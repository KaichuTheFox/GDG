package dev.aimmanager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public record AimCommandInput(String request, Coordinates coordinates) {
    private static final Pattern NULL_SUFFIX = Pattern.compile("(?is)^(.*?)\\s+(?:null|\"null\")\\s*$");
    private static final Pattern COORDINATE_SUFFIX = Pattern.compile(
            "(?s)^(.*?)\\s+(?:\"(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+)\"|(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+))\\s*$"
    );

    public static AimCommandInput parse(String rawInput) {
        String input = rawInput == null ? "" : rawInput.trim();

        Matcher nullMatcher = NULL_SUFFIX.matcher(input);
        if (nullMatcher.matches()) {
            String request = cleanRequest(nullMatcher.group(1));
            if (request.isBlank()) {
                throw new IllegalArgumentException("명령을 입력해 주세요.");
            }
            return new AimCommandInput(request, null);
        }

        Matcher coordinateMatcher = COORDINATE_SUFFIX.matcher(input);
        if (coordinateMatcher.matches()) {
            String request = cleanRequest(coordinateMatcher.group(1));
            if (request.isBlank()) {
                throw new IllegalArgumentException("명령을 입력해 주세요.");
            }

            int x = Integer.parseInt(firstNonNull(coordinateMatcher.group(2), coordinateMatcher.group(5)));
            int y = Integer.parseInt(firstNonNull(coordinateMatcher.group(3), coordinateMatcher.group(6)));
            int z = Integer.parseInt(firstNonNull(coordinateMatcher.group(4), coordinateMatcher.group(7)));
            return new AimCommandInput(request, new Coordinates(x, y, z));
        }

        throw new IllegalArgumentException("명령 끝에 좌표 X Y Z 또는 null을 입력해 주세요.");
    }

    private static String cleanRequest(String request) {
        String cleaned = request.trim();
        if (cleaned.length() >= 2 && cleaned.startsWith("\"") && cleaned.endsWith("\"")) {
            cleaned = cleaned.substring(1, cleaned.length() - 1).trim();
        }
        return cleaned;
    }

    private static String firstNonNull(String first, String second) {
        return first != null ? first : second;
    }

    public record Coordinates(int x, int y, int z) {
        @Override
        public String toString() {
            return x + " " + y + " " + z;
        }
    }
}

