package dev.aimmanager;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class AimManagerMod implements ModInitializer {
    public static final String MOD_ID = "aimmanager";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                AimCommand.register(dispatcher));
        AimConfig.load();
        LOGGER.info("AIM Manager loaded. Use /AIM help for usage.");
    }
}

