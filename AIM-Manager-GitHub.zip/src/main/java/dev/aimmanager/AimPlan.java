package dev.aimmanager;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.Locale;

public record AimPlan(Action action, String message, String blockOrItemId, Integer count, Integer width, Integer depth) {
    public enum Action {
        PLACE_RECTANGLE,
        GIVE_ITEM,
        CLARIFY,
        UNSUPPORTED
    }

    public static AimPlan fromArguments(String arguments) {
        JsonObject json = JsonParser.parseString(arguments).getAsJsonObject();
        Action action;
        try {
            action = Action.valueOf(json.get("action").getAsString().toUpperCase(Locale.ROOT));
        } catch (RuntimeException exception) {
            throw new IllegalArgumentException("AI가 알 수 없는 작업을 반환했습니다.", exception);
        }

        return new AimPlan(
                action,
                nullableString(json, "message"),
                nullableString(json, "block_or_item_id"),
                nullableInt(json, "count"),
                nullableInt(json, "width"),
                nullableInt(json, "depth")
        );
    }

    private static String nullableString(JsonObject json, String key) {
        return json.get(key) == null || json.get(key).isJsonNull() ? null : json.get(key).getAsString();
    }

    private static Integer nullableInt(JsonObject json, String key) {
        return json.get(key) == null || json.get(key).isJsonNull() ? null : json.get(key).getAsInt();
    }
}

