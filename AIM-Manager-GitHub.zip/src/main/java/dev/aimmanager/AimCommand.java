package dev.aimmanager;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ConcurrentHashMap;

public final class AimCommand {
    private static final int MAX_RECTANGLE_BLOCKS = 64;
    private static final int MAX_RECTANGLE_SIDE = 8;
    private static final int MAX_ITEM_COUNT = 64;
    private static final Set<UUID> PENDING = ConcurrentHashMap.newKeySet();

    private AimCommand() {
    }

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        registerRoot(dispatcher, "aim");
        registerRoot(dispatcher, "AIM");
    }

    private static void registerRoot(CommandDispatcher<CommandSourceStack> dispatcher, String root) {
        dispatcher.register(Commands.literal(root)
                .requires(source -> source.getEntity() instanceof ServerPlayer)
                .then(Commands.literal("help").executes(context -> showHelp(context.getSource())))
                .then(Commands.argument("request_and_coordinates", StringArgumentType.greedyString())
                        .executes(context -> handle(context.getSource(),
                                StringArgumentType.getString(context, "request_and_coordinates")))));
    }

    private static int showHelp(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal("AIM 사용법: /AIM <요청> <X Y Z 또는 null>"), false);
        source.sendSuccess(() -> Component.literal("예: /AIM 다이아몬드 블록으로 3x3 설치 100 64 200"), false);
        source.sendSuccess(() -> Component.literal("예: /AIM 다이아몬드 16개 얻기 null"), false);
        source.sendSuccess(() -> Component.literal("좌표는 설치 영역의 시작 모서리이며, X/Z 방향으로 넓어집니다."), false);
        return 1;
    }

    private static int handle(CommandSourceStack source, String rawInput) {
        Entity entity = source.getEntity();
        if (!(entity instanceof ServerPlayer player)) {
            source.sendFailure(Component.literal("AIM은 플레이어가 싱글플레이 월드에서 실행해야 합니다."));
            return 0;
        }

        MinecraftServer server = source.getServer();
        if (server.isDedicatedServer() || server.isPublished() || server.getPlayerList().getPlayers().size() != 1) {
            source.sendFailure(Component.literal("현재 AIM은 다른 플레이어가 없는 싱글플레이에서만 작동합니다."));
            return 0;
        }

        AimCommandInput input;
        try {
            input = AimCommandInput.parse(rawInput);
        } catch (IllegalArgumentException exception) {
            source.sendFailure(Component.literal(exception.getMessage()));
            source.sendFailure(Component.literal("사용법: /AIM <요청> <X Y Z 또는 null> — /AIM help"));
            return 0;
        }

        AimConfig config = AimConfig.load();
        UUID playerId = player.getUUID();
        if (!PENDING.add(playerId)) {
            source.sendFailure(Component.literal("이전 AIM 요청을 처리 중입니다. 잠시 기다려 주세요."));
            return 0;
        }

        player.sendSystemMessage(Component.literal("AIM이 요청을 분석 중입니다."));
        OllamaPlanner.plan(config, input).whenComplete((plan, error) -> {
            try {
                server.execute(() -> {
                    PENDING.remove(playerId);
                    ServerPlayer currentPlayer = server.getPlayerList().getPlayer(playerId);
                    if (currentPlayer == null) {
                        return;
                    }
                    if (error != null) {
                        currentPlayer.sendSystemMessage(Component.literal("AIM 요청 실패: " + safeErrorMessage(error)));
                        return;
                    }
                    executePlan(currentPlayer, input, plan);
                });
            } catch (RuntimeException exception) {
                PENDING.remove(playerId);
                AimManagerMod.LOGGER.warn("Could not return AIM response to the game thread", exception);
            }
        });
        return 1;
    }

    private static String safeErrorMessage(Throwable error) {
        Throwable cause = error;
        while ((cause instanceof CompletionException || cause.getCause() != null) && cause.getCause() != null) {
            cause = cause.getCause();
        }
        if (cause instanceof OllamaPlanner.PlannerException) {
            return cause.getMessage();
        }
        if (cause instanceof java.net.ConnectException || cause instanceof java.net.http.HttpConnectTimeoutException) {
            return "로컬 AI Ollama에 연결할 수 없습니다. Ollama가 실행 중인지 확인해 주세요.";
        }
        return "로컬 AI 응답을 읽지 못했습니다. Ollama 실행 상태와 설정을 확인해 주세요.";
    }

    private static void executePlan(ServerPlayer player, AimCommandInput input, AimPlan plan) {
        if (plan == null) {
            player.sendSystemMessage(Component.literal("AI가 빈 응답을 반환했습니다. 다시 시도해 주세요."));
            return;
        }

        switch (plan.action()) {
            case CLARIFY -> player.sendSystemMessage(Component.literal("AIM: " + safeMessage(plan.message(), "요청을 더 구체적으로 적어 주세요.")));
            case UNSUPPORTED -> player.sendSystemMessage(Component.literal("AIM: " + safeMessage(plan.message(), "아직 지원하지 않는 명령입니다.")));
            case GIVE_ITEM -> giveItem(player, input, plan);
            case PLACE_RECTANGLE -> placeRectangle(player, input, plan);
        }
    }

    private static void giveItem(ServerPlayer player, AimCommandInput input, AimPlan plan) {
        if (input.coordinates() != null) {
            player.sendSystemMessage(Component.literal("아이템 획득에는 좌표가 필요 없으므로 마지막에 null을 입력해 주세요."));
            return;
        }
        if (plan.blockOrItemId() == null || plan.count() == null || plan.count() < 1 || plan.count() > MAX_ITEM_COUNT) {
            player.sendSystemMessage(Component.literal("아이템 또는 수량이 올바르지 않습니다. 수량은 1~64개로 요청해 주세요."));
            return;
        }

        Identifier id = parseId(plan.blockOrItemId());
        if (id == null) {
            player.sendSystemMessage(Component.literal("AI가 올바른 아이템 ID를 반환하지 않았습니다."));
            return;
        }
        Item item = BuiltInRegistries.ITEM.getOptional(id).orElse(null);
        if (item == null || item == net.minecraft.world.item.Items.AIR) {
            player.sendSystemMessage(Component.literal("존재하지 않는 아이템입니다: " + id));
            return;
        }

        if (!hasInventorySpace(player, item, plan.count())) {
            player.sendSystemMessage(Component.literal("인벤토리에 공간이 부족해 아이템을 지급하지 않았습니다."));
            return;
        }

        var inventory = player.getInventory();
        List<ItemStack> previousItems = new ArrayList<>(36);
        for (int slot = 0; slot < 36; slot++) {
            previousItems.add(inventory.getItem(slot).copy());
        }
        boolean added = inventory.add(new ItemStack(item, plan.count()));
        if (!added) {
            for (int slot = 0; slot < 36; slot++) {
                inventory.setItem(slot, previousItems.get(slot));
            }
            inventory.setChanged();
            player.containerMenu.broadcastChanges();
            player.sendSystemMessage(Component.literal("인벤토리 지급에 실패했습니다. 아이템은 지급하지 않았습니다."));
            return;
        }

        inventory.setChanged();
        player.containerMenu.broadcastChanges();
        player.sendSystemMessage(Component.literal(id + " " + plan.count() + "개를 지급했습니다."));
    }

    private static boolean hasInventorySpace(ServerPlayer player, Item item, int count) {
        int capacity = 0;
        ItemStack prototype = new ItemStack(item);
        for (int slot = 0; slot < 36; slot++) {
            ItemStack stack = player.getInventory().getItem(slot);
            if (stack.isEmpty()) {
                capacity += prototype.getMaxStackSize();
            } else if (ItemStack.isSameItemSameComponents(stack, prototype)) {
                capacity += Math.max(0, stack.getMaxStackSize() - stack.getCount());
            }
            if (capacity >= count) {
                return true;
            }
        }
        return false;
    }

    private static void placeRectangle(ServerPlayer player, AimCommandInput input, AimPlan plan) {
        AimCommandInput.Coordinates coordinates = input.coordinates();
        if (coordinates == null) {
            player.sendSystemMessage(Component.literal("블록 설치에는 좌표가 필요합니다. 명령 마지막에 X Y Z를 입력해 주세요."));
            return;
        }
        if (plan.blockOrItemId() == null || plan.width() == null || plan.depth() == null
                || plan.width() < 1 || plan.depth() < 1
                || plan.width() > MAX_RECTANGLE_SIDE || plan.depth() > MAX_RECTANGLE_SIDE
                || (long) plan.width() * plan.depth() > MAX_RECTANGLE_BLOCKS) {
            player.sendSystemMessage(Component.literal("현재 AIM은 한 번에 최대 8x8(64블록) 수평 영역만 설치합니다."));
            return;
        }

        Identifier id = parseId(plan.blockOrItemId());
        if (id == null) {
            player.sendSystemMessage(Component.literal("AI가 올바른 블록 ID를 반환하지 않았습니다."));
            return;
        }
        Block block = BuiltInRegistries.BLOCK.getOptional(id).orElse(null);
        if (block == null || block == Blocks.AIR) {
            player.sendSystemMessage(Component.literal("존재하지 않는 설치용 블록입니다: " + id));
            return;
        }
        if (!(block.asItem() instanceof BlockItem)) {
            player.sendSystemMessage(Component.literal("이 블록은 현재 설치 기능에서 지원되지 않습니다."));
            return;
        }

        ServerLevel level = player.level();
        long endX = (long) coordinates.x() + plan.width() - 1;
        long endZ = (long) coordinates.z() + plan.depth() - 1;
        if (coordinates.y() < level.getMinY() || coordinates.y() > level.getMaxY()
                || endX > Integer.MAX_VALUE || endZ > Integer.MAX_VALUE
                || endX < Integer.MIN_VALUE || endZ < Integer.MIN_VALUE) {
            player.sendSystemMessage(Component.literal("좌표가 월드의 허용 범위를 벗어났습니다."));
            return;
        }

        BlockState state = block.defaultBlockState();
        List<BlockPos> positions = new ArrayList<>();
        for (int dx = 0; dx < plan.width(); dx++) {
            for (int dz = 0; dz < plan.depth(); dz++) {
                BlockPos position = new BlockPos(coordinates.x() + dx, coordinates.y(), coordinates.z() + dz);
                if (!level.hasChunkAt(position)) {
                    player.sendSystemMessage(Component.literal("설치 좌표가 로드된 청크 밖에 있습니다. 플레이어 가까운 좌표를 사용해 주세요."));
                    return;
                }
                positions.add(position);
            }
        }

        int changed = 0;
        for (BlockPos position : positions) {
            if (level.setBlock(position, state, 3)) {
                changed++;
            }
        }
        player.sendSystemMessage(Component.literal(id + " 블록 " + plan.width() + "x" + plan.depth()
                + " 영역을 설치했습니다. 좌표 시작점: " + coordinates + " (변경 " + changed + "블록)"));
    }

    private static Identifier parseId(String rawId) {
        String normalized = rawId.trim();
        if (!normalized.contains(":")) {
            normalized = "minecraft:" + normalized;
        }
        return Identifier.tryParse(normalized);
    }

    private static String safeMessage(String message, String fallback) {
        if (message == null || message.isBlank()) {
            return fallback;
        }
        String oneLine = message.replace('\n', ' ').replace('\r', ' ').trim();
        return oneLine.length() <= 180 ? oneLine : oneLine.substring(0, 180) + "…";
    }
}

