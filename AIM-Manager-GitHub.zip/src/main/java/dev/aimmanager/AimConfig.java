package dev.aimmanager;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public record AimConfig(String model) {
    private static final String MODEL = "ollama.model";
    private static final String DEFAULT_MODEL = "qwen3:4b";

    public static AimConfig load() {
        Path configPath = FabricLoader.getInstance().getConfigDir().resolve("aimmanager.properties");
        Properties properties = new Properties();
        boolean changed = false;

        if (Files.exists(configPath)) {
            try (var reader = Files.newBufferedReader(configPath)) {
                properties.load(reader);
            } catch (IOException | IllegalArgumentException exception) {
                AimManagerMod.LOGGER.error("Could not read AIM Manager config at {}", configPath, exception);
            }
        }

        if (properties.getProperty(MODEL) == null || properties.getProperty(MODEL).isBlank()) {
            properties.setProperty(MODEL, DEFAULT_MODEL);
            changed = true;
        }

        // Remove the legacy OpenAI secret from the old config after switching to local Ollama.
        if (properties.remove("openai.apiKey") != null) {
            changed = true;
        }

        if (changed || !Files.exists(configPath)) {
            try {
                Files.createDirectories(configPath.getParent());
                try (Writer writer = Files.newBufferedWriter(configPath)) {
                    properties.store(writer, "AIM Manager local Ollama settings. No API key required.");
                }
            } catch (IOException exception) {
                AimManagerMod.LOGGER.error("Could not write AIM Manager config at {}", configPath, exception);
            }
        }

        return new AimConfig(properties.getProperty(MODEL, DEFAULT_MODEL).trim());
    }
}

