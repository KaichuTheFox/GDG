# AIM Manager

Minecraft Java Edition 1.21.11용 Fabric 싱글플레이 모드입니다. `/AIM` 뒤에 자연어 요청과 좌표 또는 `null`을 입력하면, Ollama 로컬 AI가 작업을 해석합니다.

## 학교 노트북에서 빠르게 실행하기

학교 노트북 사양: RAM 8GB, Intel Core i5, 내장 그래픽. 이 사양에서는 기본 모델 `qwen3:4b`가 부담스러울 수 있으므로 `qwen3:1.7b`부터 시도하세요. 모델 파일은 약 1.4GB이고, 실제 실행 중에는 파일 크기보다 메모리를 더 사용할 수 있습니다. [Qwen3 모델 용량](https://ollama.com/library/qwen3)

1. 학교 노트북에서 Minecraft Java 1.21.11과 Fabric 프로필이 실행되는지 확인합니다.
2. [Ollama for Windows](https://ollama.com/download/windows)를 설치합니다. 학교 기기에서 설치가 제한되어 있으면 관리자에게 확인하세요.
3. 명령 프롬프트 또는 새 PowerShell에서 학교 노트북용 모델을 받습니다.

   ```text
   ollama pull qwen3:1.7b
   ```

   최초 다운로드에 인터넷이 필요합니다. 완료 후 `ollama list`에서 `qwen3:1.7b`가 보이는지 확인합니다.
4. 이 프로젝트의 `release/aim-manager-0.2.0.jar` 파일을 `%appdata%\.minecraft\mods`에 복사합니다. 기존 `aim-manager-0.1.0.jar`는 폴더 밖으로 옮기고, `fabric-api` JAR는 그대로 둡니다. `-sources.jar`는 설치하지 않습니다.
5. `%appdata%\.minecraft\config\aimmanager.properties` 파일을 만들거나 열어서 아래 내용을 저장합니다. `config` 폴더가 없으면 먼저 만듭니다.

   ```properties
   ollama.model=qwen3:1.7b
   ```

6. Ollama가 실행 중인 상태에서 Fabric 1.21.11 프로필로 게임을 열고 `/AIM help`를 입력합니다. AI를 확인할 때는 `/AIM 다이아몬드 1개 얻기 null`을 사용합니다.

8GB RAM과 내장 그래픽에서는 마인크래프트와 AI가 동시에 메모리와 CPU를 사용해 끊길 수 있습니다. 브라우저 등 다른 프로그램을 닫고 시도하세요. 그래도 느리면 `ollama pull qwen3:0.6b`를 실행한 뒤 설정을 `ollama.model=qwen3:0.6b`로 바꿀 수 있지만, 작은 모델은 요청 해석이 덜 정확할 수 있습니다. RTX 3060이 있는 개인 PC에서는 `qwen3:4b`를 사용할 수 있습니다.

## 명령 문법

```text
/AIM "요청 내용" "X Y Z"
/AIM "요청 내용" null
```

- 블록 설치에는 X, Y, Z 좌표가 필요합니다. `100 64 200`과 같이 씁니다.
- 좌표가 필요 없는 아이템 지급 명령은 끝에 `null`을 씁니다.
- 지원 작업은 수평 직사각형 블록 설치와 아이템 지급입니다.
- 블록 설치는 시작점에서 +X, +Z 방향으로 펼쳐지며 한 번에 최대 8x8(64블록)입니다. 설치 위치의 기존 블록을 덮어쓸 수 있습니다.
- 아이템 지급은 한 번에 1~64개입니다.
- 다른 플레이어가 있거나 LAN 공개된 월드 및 서버에서는 작동하지 않습니다.

예:

```text
/AIM "다이아몬드 블록으로 3x3 설치" "100 64 200"
/AIM "다이아몬드 16개 얻기" null
```

## 로컬 AI와 비용

AIM은 `http://127.0.0.1:11434/api/chat`의 Ollama 로컬 API만 호출합니다. OpenAI API 키나 결제가 필요하지 않습니다. 모델 다운로드 때만 인터넷이 필요하며, 내려받은 뒤 AI 요청은 PC 안에서 처리합니다. 모델 실행 중 게임이 느려질 수 있습니다.

이전 0.1.0 버전에서 저장했던 `openai.apiKey`는 0.2.0을 실행하고 AIM 명령을 처음 처리할 때 설정 파일에서 자동으로 제거됩니다. API 키를 채팅이나 GitHub에 올리지 마세요.

## 현재 버전 및 빌드

- AIM 모드 0.2.0
- Minecraft Java 1.21.11, Java 21
- Fabric Loader 0.18.4 이상
- Fabric API 0.141.6+1.21.11
- Gradle 9.2.0 및 Fabric Loom 1.14.10

미리 빌드한 실행 파일은 `release/aim-manager-0.2.0.jar`입니다. 소스에서 다시 빌드하려면 Java 21과 Gradle이 필요합니다. 프로젝트에서 `gradle build`를 실행하면 JAR가 `build/libs/`에 생성됩니다. 현재 프로젝트에는 Gradle Wrapper가 포함되어 있지 않습니다.

## 참고

- [Ollama Windows 설치](https://ollama.com/download/windows)
- [Ollama Qwen3 모델 및 크기](https://ollama.com/library/qwen3)
- [Ollama 구조화된 출력](https://ollama.com/blog/structured-outputs)
