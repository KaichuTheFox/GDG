#include "zlang/Semantic.h"

namespace zlang {

SemanticAnalyzer::SemanticAnalyzer(Diagnostics& diagnostics) : diagnostics_(diagnostics) {}

void SemanticAnalyzer::pushScope() { scopes_.emplace_back(); }
void SemanticAnalyzer::popScope() { scopes_.pop_back(); }

std::optional<SemanticAnalyzer::VariableSymbol>
SemanticAnalyzer::findVariable(const std::string& name) const
{
    for (auto scope = scopes_.rbegin(); scope != scopes_.rend(); ++scope) {
        const auto symbol = scope->find(name);
        if (symbol != scope->end()) {
            return symbol->second;
        }
    }
    return std::nullopt;
}

bool SemanticAnalyzer::typesCompatible(Type expected, Type actual) const
{
    return expected == actual || expected == Type::Unknown || actual == Type::Unknown;
}

bool SemanticAnalyzer::analyze(Program& program)
{
    int mainCount = 0;

    for (auto& function : program.functions) {
        if (functions_.count(function->name) != 0) {
            diagnostics_.error(function->span, "duplicate function '" + function->name + "'");
        } else {
            functions_[function->name] = function.get();
        }

        if (function->name == "main") {
            ++mainCount;
            if (!function->params.empty()) {
                diagnostics_.error(function->span, "main cannot have parameters");
            }
        }
    }

    if (mainCount == 0) {
        diagnostics_.error({}, "program requires exactly one main function");
    }
    if (mainCount > 1) {
        diagnostics_.error({}, "program must not define more than one main function");
    }

    // A small fixed-point pass lets forward and recursive calls observe discovered return types.
    for (int pass = 0; pass < 1; ++pass) {
        for (auto& function : program.functions) {
            currentFunction_ = function.get();
            pushScope();
            for (const auto& parameter : function->params) {
                scopes_.back()[parameter] = {Type::Unknown, false};
            }

            Type returnType = Type::Unknown;
            for (auto& statement : function->body->statements) {
                analyzeStatement(*statement, returnType);
            }
            function->returnType = returnType;
            popScope();
        }
    }

    return !diagnostics_.hasErrors();
}

void SemanticAnalyzer::analyzeStatement(Stmt& statement, Type& returnType)
{
    if (auto* declaration = dynamic_cast<VarDecl*>(&statement)) {
        for (const auto& scope : scopes_) {
            if (scope.count(declaration->name) != 0) {
                diagnostics_.error(declaration->span,
                                   "duplicate or shadowed variable '" + declaration->name + "'");
                return;
            }
        }
        const Type initialType = analyzeExpression(*declaration->init);
        if (!typesCompatible(declaration->type, initialType)) {
            diagnostics_.error(declaration->span,
                               "initializer type does not match variable type");
        }
        scopes_.back()[declaration->name] = {declaration->type, false};
        return;
    }

    if (auto* assignment = dynamic_cast<Assign*>(&statement)) {
        const auto variable = findVariable(assignment->name);
        if (!variable) {
            diagnostics_.error(assignment->span,
                               "use of undeclared variable '" + assignment->name + "'");
        } else if (variable->isReadOnly) {
            diagnostics_.error(assignment->span, "cannot assign to read-only for variable");
        } else if (!typesCompatible(variable->type, analyzeExpression(*assignment->value))) {
            diagnostics_.error(assignment->span, "assignment type mismatch");
        }
        return;
    }

    if (auto* print = dynamic_cast<Print*>(&statement)) {
        for (auto& argument : print->args) {
            analyzeExpression(*argument);
        }
        return;
    }

    if (auto* conditional = dynamic_cast<If*>(&statement)) {
        if (analyzeExpression(*conditional->cond) != Type::Bool) {
            diagnostics_.error(conditional->cond->span, "if condition must be bool");
        }
        pushScope();
        for (auto& child : conditional->thenBlock->statements) {
            analyzeStatement(*child, returnType);
        }
        popScope();

        for (auto& branch : conditional->elseIfs) {
            if (analyzeExpression(*branch.first) != Type::Bool) {
                diagnostics_.error(branch.first->span, "else-if condition must be bool");
            }
            pushScope();
            for (auto& child : branch.second->statements) {
                analyzeStatement(*child, returnType);
            }
            popScope();
        }

        if (conditional->elseBlock) {
            pushScope();
            for (auto& child : conditional->elseBlock->statements) {
                analyzeStatement(*child, returnType);
            }
            popScope();
        }
        return;
    }

    if (auto* loop = dynamic_cast<While*>(&statement)) {
        if (analyzeExpression(*loop->cond) != Type::Bool) {
            diagnostics_.error(loop->cond->span, "while condition must be bool");
        }
        pushScope();
        for (auto& child : loop->body->statements) {
            analyzeStatement(*child, returnType);
        }
        popScope();
        return;
    }

    if (auto* loop = dynamic_cast<For*>(&statement)) {
        if (analyzeExpression(*loop->end) != Type::Box) {
            diagnostics_.error(loop->end->span, "for range must be box");
        }
        pushScope();
        scopes_.back()[loop->name] = {Type::Box, true};
        for (auto& child : loop->body->statements) {
            analyzeStatement(*child, returnType);
        }
        popScope();
        return;
    }

    if (auto* returnStatement = dynamic_cast<Return*>(&statement)) {
        const Type discovered = returnStatement->value
                                    ? analyzeExpression(*returnStatement->value)
                                    : Type::Void;
        if (returnType == Type::Unknown) {
            returnType = discovered;
        } else if (!typesCompatible(returnType, discovered)) {
            diagnostics_.error(returnStatement->span, "incompatible function return types");
        }
        return;
    }

    if (auto* expressionStatement = dynamic_cast<ExprStmt*>(&statement)) {
        analyzeExpression(*expressionStatement->expr, false);
    }
}

Type SemanticAnalyzer::analyzeExpression(Expr& expression, bool valueRequired)
{
    Type result = Type::Unknown;

    if (auto* literal = dynamic_cast<LiteralExpr*>(&expression)) {
        result = std::holds_alternative<std::string>(literal->value)
                     ? Type::Line
                     : std::holds_alternative<bool>(literal->value) ? Type::Bool : Type::Box;
    } else if (auto* name = dynamic_cast<NameExpr*>(&expression)) {
        const auto variable = findVariable(name->name);
        if (!variable) {
            diagnostics_.error(name->span, "use of undeclared variable '" + name->name + "'");
        } else {
            result = variable->type;
        }
    } else if (auto* unary = dynamic_cast<UnaryExpr*>(&expression)) {
        result = analyzeExpression(*unary->rhs);
        if (result != Type::Box && result != Type::Unknown) {
            diagnostics_.error(unary->span, "unary operator requires box");
        }
    } else if (auto* binary = dynamic_cast<BinaryExpr*>(&expression)) {
        const Type left = analyzeExpression(*binary->lhs);
        const Type right = analyzeExpression(*binary->rhs);

        if (binary->op == "==" || binary->op == "!=") {
            if (!typesCompatible(left, right)) {
                diagnostics_.error(binary->span, "comparison type mismatch");
            }
            result = Type::Bool;
        } else if (binary->op == "<" || binary->op == "<=" || binary->op == ">" ||
                   binary->op == ">=") {
            if ((left != Type::Box && left != Type::Unknown) ||
                (right != Type::Box && right != Type::Unknown)) {
                diagnostics_.error(binary->span, "ordered comparison requires box");
            }
            result = Type::Bool;
        } else if (left == Type::Unknown || right == Type::Unknown) {
            result = Type::Unknown;
        } else if (binary->op == "+" && left == Type::Line && right == Type::Line) {
            result = Type::Line;
        } else if (left == Type::Box && right == Type::Box) {
            result = Type::Box;
        } else if (left == Type::Cpx && right == Type::Cpx) {
            result = Type::Cpx;
        } else {
            diagnostics_.error(binary->span, "invalid operands for '" + binary->op + "'");
        }
    } else if (auto* call = dynamic_cast<CallExpr*>(&expression)) {
        if (call->callee == "cpx") {
            if (call->args.size() != 2) {
                diagnostics_.error(call->span, "cpx requires exactly 2 arguments");
            }
            for (auto& argument : call->args) {
                if (analyzeExpression(*argument) != Type::Box) {
                    diagnostics_.error(argument->span, "cpx arguments must be box");
                }
            }
            result = Type::Cpx;
        } else {
            const auto function = functions_.find(call->callee);
            if (function == functions_.end()) {
                diagnostics_.error(call->span, "unknown function '" + call->callee + "'");
            } else {
                if (call->args.size() != function->second->params.size()) {
                    diagnostics_.error(call->span, "function argument count mismatch");
                }
                for (auto& argument : call->args) {
                    analyzeExpression(*argument);
                }
                result = function->second->returnType;
            }
        }
    }

    if (valueRequired && result == Type::Void) {
        diagnostics_.error(expression.span, "void function result used as a value");
    }
    expression.inferred = result;
    return result;
}

} // namespace zlang
