#include "zlang/Parser.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace zlang {

Parser::Parser(std::vector<Token> tokens, Diagnostics& diagnostics)
    : tokens_(std::move(tokens)), diagnostics_(diagnostics)
{
}

const Token& Parser::peek(std::size_t lookahead) const
{
    return tokens_[std::min(current_ + lookahead, tokens_.size() - 1)];
}

bool Parser::at(TokenKind kind) const
{
    return peek().kind == kind;
}

bool Parser::match(TokenKind kind)
{
    if (!at(kind)) {
        return false;
    }
    ++current_;
    return true;
}

const Token& Parser::expect(TokenKind kind, const char* message)
{
    if (at(kind)) {
        return tokens_[current_++];
    }
    diagnostics_.error(peek().span, message);
    fatalError_ = true;
    return peek();
}

void Parser::consumeTerminators()
{
    while (match(TokenKind::NewLine) || match(TokenKind::Semicolon)) {
    }
}

void Parser::synchronizeStatement()
{
    while (!at(TokenKind::Eof) && !at(TokenKind::RBrace) && !at(TokenKind::NewLine) &&
           !at(TokenKind::Semicolon)) {
        ++current_;
    }
    consumeTerminators();
}

Program Parser::parse()
{
    Program program;
    consumeTerminators();

    while (!at(TokenKind::Eof)) {
        const std::size_t before = current_;
        auto function = parseFunction();
        if (function) {
            program.functions.push_back(std::move(function));
        }
        consumeTerminators();

        if (current_ == before) {
            diagnostics_.error(peek().span, "parser could not make progress");
            ++current_;
        }
    }
    return program;
}

std::unique_ptr<Function> Parser::parseFunction()
{
    auto function = std::make_unique<Function>();
    const Token& name = at(TokenKind::Main)
                            ? expect(TokenKind::Main, "function name expected")
                            : expect(TokenKind::Identifier, "function name expected");
    if (fatalError_ && name.kind == TokenKind::Eof) {
        return nullptr;
    }

    function->name = name.lexeme;
    function->span.begin = name.span.begin;
    expect(TokenKind::LParen, "expected '('");

    if (!at(TokenKind::RParen)) {
        do {
            function->params.push_back(expect(TokenKind::Identifier, "parameter expected").lexeme);
        } while (match(TokenKind::Comma));
    }

    expect(TokenKind::RParen, "expected ')'");
    consumeTerminators();
    function->body = parseBlock();
    if (!function->body) {
        return nullptr;
    }
    function->span.end = function->body->span.end;
    fatalError_ = false;
    return function;
}

std::unique_ptr<Block> Parser::parseBlock()
{
    auto block = std::make_unique<Block>();
    const Token& opening = expect(TokenKind::LBrace, "expected '{'");
    block->span.begin = opening.span.begin;
    consumeTerminators();

    while (!at(TokenKind::RBrace) && !at(TokenKind::Eof)) {
        const std::size_t before = current_;
        block->statements.push_back(parseStatement());

        consumeTerminators();

        if (current_ == before) {
            ++current_;
        }
    }

    const Token& closing = expect(TokenKind::RBrace, "expected '}'");
    block->span.end = closing.span.end;
    return block;
}

StmtPtr Parser::parseStatement()
{
    if (at(TokenKind::Box) || at(TokenKind::Line) || at(TokenKind::Bool) ||
        at(TokenKind::Cpx)) {
        auto statement = std::make_unique<VarDecl>();
        const TokenKind type = peek().kind;
        statement->span.begin = peek().span.begin;
        ++current_;
        statement->type = type == TokenKind::Box    ? Type::Box
                          : type == TokenKind::Line ? Type::Line
                          : type == TokenKind::Bool ? Type::Bool
                                                   : Type::Cpx;
        statement->name = expect(TokenKind::Identifier, "variable name expected").lexeme;
        expect(TokenKind::Assign, "expected '='");
        statement->init = parseExpression();
        statement->span.end = statement->init->span.end;
        return statement;
    }

    if (match(TokenKind::Print)) {
        auto statement = std::make_unique<Print>();
        statement->span.begin = tokens_[current_ - 1].span.begin;
        const bool parenthesized = match(TokenKind::LParen);
        if (!(parenthesized && at(TokenKind::RParen)) && !at(TokenKind::NewLine) &&
            !at(TokenKind::Semicolon) && !at(TokenKind::RBrace)) {
            do {
                statement->args.push_back(parseExpression());
            } while (match(TokenKind::Comma));
        }
        if (parenthesized) {
            statement->span.end = expect(TokenKind::RParen, "expected ')'").span.end;
        } else {
            statement->span.end = peek().span.begin;
        }
        return statement;
    }

    if (match(TokenKind::If)) {
        auto statement = std::make_unique<If>();
        statement->span.begin = tokens_[current_ - 1].span.begin;
        expect(TokenKind::LParen, "expected '('");
        statement->cond = parseExpression();
        expect(TokenKind::RParen, "expected ')'");
        consumeTerminators();
        statement->thenBlock = parseBlock();
        consumeTerminators();

        while (match(TokenKind::Else)) {
            if (match(TokenKind::If)) {
                expect(TokenKind::LParen, "expected '('");
                auto condition = parseExpression();
                expect(TokenKind::RParen, "expected ')'");
                consumeTerminators();
                statement->elseIfs.push_back({std::move(condition), parseBlock()});
                consumeTerminators();
            } else {
                statement->elseBlock = parseBlock();
                break;
            }
        }
        statement->span.end = statement->elseBlock ? statement->elseBlock->span.end
                                                   : statement->thenBlock->span.end;
        return statement;
    }

    if (match(TokenKind::While)) {
        auto statement = std::make_unique<While>();
        statement->span.begin = tokens_[current_ - 1].span.begin;
        expect(TokenKind::LParen, "expected '('");
        statement->cond = parseExpression();
        expect(TokenKind::RParen, "expected ')'");
        consumeTerminators();
        statement->body = parseBlock();
        statement->span.end = statement->body->span.end;
        return statement;
    }

    if (match(TokenKind::For)) {
        auto statement = std::make_unique<For>();
        statement->span.begin = tokens_[current_ - 1].span.begin;
        statement->name = expect(TokenKind::Identifier, "loop variable expected").lexeme;
        expect(TokenKind::In, "expected 'in'");
        expect(TokenKind::Plus, "expected '+('");
        expect(TokenKind::LParen, "expected '('");
        statement->end = parseExpression();
        expect(TokenKind::RParen, "expected ')'");
        consumeTerminators();
        statement->body = parseBlock();
        statement->span.end = statement->body->span.end;
        return statement;
    }

    if (match(TokenKind::Return)) {
        auto statement = std::make_unique<Return>();
        statement->span.begin = tokens_[current_ - 1].span.begin;
        if (!at(TokenKind::NewLine) && !at(TokenKind::Semicolon) && !at(TokenKind::RBrace)) {
            statement->value = parseExpression();
        }
        statement->span.end = statement->value ? statement->value->span.end : peek().span.begin;
        return statement;
    }

    if (at(TokenKind::Identifier) && peek(1).kind == TokenKind::Assign) {
        auto statement = std::make_unique<Assign>();
        statement->span.begin = peek().span.begin;
        statement->name = peek().lexeme;
        current_ += 2;
        statement->value = parseExpression();
        statement->span.end = statement->value->span.end;
        return statement;
    }

    auto statement = std::make_unique<ExprStmt>();
    statement->expr = parseExpression();
    statement->span = statement->expr->span;
    return statement;
}

ExprPtr Parser::parseExpression() { return parseEquality(); }

ExprPtr Parser::parseEquality()
{
    auto expression = parseComparison();
    while (at(TokenKind::EqEq) || at(TokenKind::NotEq)) {
        const std::string op = peek().lexeme;
        ++current_;
        auto right = parseComparison();
        auto binary = std::make_unique<BinaryExpr>();
        binary->span = {expression->span.begin, right->span.end};
        binary->lhs = std::move(expression);
        binary->op = op;
        binary->rhs = std::move(right);
        expression = std::move(binary);
    }
    return expression;
}

ExprPtr Parser::parseComparison()
{
    auto expression = parseAdditive();
    while (at(TokenKind::Less) || at(TokenKind::LessEq) || at(TokenKind::Greater) ||
           at(TokenKind::GreaterEq)) {
        const std::string op = peek().lexeme;
        ++current_;
        auto right = parseAdditive();
        auto binary = std::make_unique<BinaryExpr>();
        binary->span = {expression->span.begin, right->span.end};
        binary->lhs = std::move(expression);
        binary->op = op;
        binary->rhs = std::move(right);
        expression = std::move(binary);
    }
    return expression;
}

ExprPtr Parser::parseAdditive()
{
    auto expression = parseMultiplicative();
    while (at(TokenKind::Plus) || at(TokenKind::Minus)) {
        const std::string op = peek().lexeme;
        ++current_;
        auto right = parseMultiplicative();
        auto binary = std::make_unique<BinaryExpr>();
        binary->span = {expression->span.begin, right->span.end};
        binary->lhs = std::move(expression);
        binary->op = op;
        binary->rhs = std::move(right);
        expression = std::move(binary);
    }
    return expression;
}

ExprPtr Parser::parseMultiplicative()
{
    auto expression = parseUnary();
    while (at(TokenKind::Star) || at(TokenKind::Slash)) {
        const std::string op = peek().lexeme;
        ++current_;
        auto right = parseUnary();
        auto binary = std::make_unique<BinaryExpr>();
        binary->span = {expression->span.begin, right->span.end};
        binary->lhs = std::move(expression);
        binary->op = op;
        binary->rhs = std::move(right);
        expression = std::move(binary);
    }
    return expression;
}

ExprPtr Parser::parseUnary()
{
    if (at(TokenKind::Plus) || at(TokenKind::Minus)) {
        const Token op = peek();
        ++current_;
        auto expression = std::make_unique<UnaryExpr>();
        expression->span.begin = op.span.begin;
        expression->op = op.lexeme;
        expression->rhs = parseUnary();
        expression->span.end = expression->rhs->span.end;
        return expression;
    }
    return parseCall();
}

ExprPtr Parser::parseCall()
{
    auto expression = parsePrimary();
    while (match(TokenKind::LParen)) {
        auto call = std::make_unique<CallExpr>();
        call->span.begin = expression->span.begin;
        if (const auto* name = dynamic_cast<NameExpr*>(expression.get())) {
            call->callee = name->name;
        } else {
            diagnostics_.error(expression->span, "only a function name can be called");
        }
        if (!at(TokenKind::RParen)) {
            do {
                call->args.push_back(parseExpression());
            } while (match(TokenKind::Comma));
        }
        call->span.end = expect(TokenKind::RParen, "expected ')'").span.end;
        expression = std::move(call);
    }
    return expression;
}

ExprPtr Parser::parsePrimary()
{
    const Token token = peek();

    if (match(TokenKind::Integer)) {
        auto expression = std::make_unique<LiteralExpr>();
        try {
            expression->value = static_cast<std::int64_t>(std::stoll(token.lexeme));
        } catch (...) {
            diagnostics_.error(token.span, "integer literal is outside int64 range");
            expression->value = std::int64_t{0};
        }
        expression->span = token.span;
        return expression;
    }

    if (match(TokenKind::Floating)) {
        auto expression = std::make_unique<LiteralExpr>();
        try {
            const double value = std::stod(token.lexeme);
            if (!std::isfinite(value)) {
                throw std::out_of_range("floating literal");
            }
            expression->value = value;
        } catch (...) {
            diagnostics_.error(token.span, "invalid or out-of-range floating literal");
            expression->value = 0.0;
        }
        expression->span = token.span;
        return expression;
    }

    if (match(TokenKind::String)) {
        auto expression = std::make_unique<LiteralExpr>();
        expression->value = token.lexeme;
        expression->span = token.span;
        return expression;
    }

    if (match(TokenKind::True) || match(TokenKind::False)) {
        auto expression = std::make_unique<LiteralExpr>();
        expression->value = token.kind == TokenKind::True;
        expression->span = token.span;
        return expression;
    }

    if (match(TokenKind::Identifier) || match(TokenKind::Cpx)) {
        auto expression = std::make_unique<NameExpr>();
        expression->name = token.lexeme;
        expression->span = token.span;
        return expression;
    }

    if (match(TokenKind::LParen)) {
        const SourceLocation begin = token.span.begin;
        auto expression = parseExpression();
        const Token& closing = expect(TokenKind::RParen, "expected ')'");
        expression->span = {begin, closing.span.end};
        return expression;
    }

    diagnostics_.error(token.span, "expected expression");
    if (!at(TokenKind::Eof)) {
        ++current_;
    }
    auto fallback = std::make_unique<LiteralExpr>();
    fallback->value = std::int64_t{0};
    fallback->span = token.span;
    return fallback;
}

} // namespace zlang
