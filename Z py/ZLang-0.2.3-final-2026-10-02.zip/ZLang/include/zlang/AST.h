#pragma once

#include "zlang/Common.h"

#include <complex>
#include <memory>
#include <string>
#include <utility>
#include <vector>

namespace zlang {

enum class Type { Unknown, Box, Line, Bool, Cpx, Void };

struct Expr {
    SourceSpan span;
    Type inferred = Type::Unknown;
    virtual ~Expr() = default;
};
using ExprPtr = std::unique_ptr<Expr>;

struct LiteralExpr final : Expr { std::variant<std::int64_t, double, std::string, bool> value; };
struct NameExpr final : Expr { std::string name; };
struct UnaryExpr final : Expr { std::string op; ExprPtr rhs; };
struct BinaryExpr final : Expr { ExprPtr lhs; std::string op; ExprPtr rhs; };
struct CallExpr final : Expr { std::string callee; std::vector<ExprPtr> args; };

struct Stmt {
    SourceSpan span;
    virtual ~Stmt() = default;
};
using StmtPtr = std::unique_ptr<Stmt>;

struct Block final : Stmt { std::vector<StmtPtr> statements; };
struct VarDecl final : Stmt { Type type = Type::Unknown; std::string name; ExprPtr init; };
struct Assign final : Stmt { std::string name; ExprPtr value; };
struct Print final : Stmt { std::vector<ExprPtr> args; };
struct If final : Stmt {
    ExprPtr cond;
    std::unique_ptr<Block> thenBlock;
    std::vector<std::pair<ExprPtr, std::unique_ptr<Block>>> elseIfs;
    std::unique_ptr<Block> elseBlock;
};
struct While final : Stmt { ExprPtr cond; std::unique_ptr<Block> body; };
struct For final : Stmt { std::string name; ExprPtr end; std::unique_ptr<Block> body; };
struct Return final : Stmt { ExprPtr value; };
struct ExprStmt final : Stmt { ExprPtr expr; };

struct Function {
    SourceSpan span;
    std::string name;
    std::vector<std::string> params;
    std::unique_ptr<Block> body;
    Type returnType = Type::Unknown;
};

struct Program { std::vector<std::unique_ptr<Function>> functions; };

} // namespace zlang
