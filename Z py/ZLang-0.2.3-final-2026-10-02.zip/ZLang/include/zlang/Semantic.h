#pragma once

#include "zlang/AST.h"

#include <optional>
#include <unordered_map>

namespace zlang {

class SemanticAnalyzer {
public:
    explicit SemanticAnalyzer(Diagnostics& diagnostics);
    bool analyze(Program& program);

private:
    struct VariableSymbol { Type type = Type::Unknown; bool isReadOnly = false; };

    void analyzeStatement(Stmt& statement, Type& returnType);
    Type analyzeExpression(Expr& expression, bool valueRequired = true);
    [[nodiscard]] bool typesCompatible(Type expected, Type actual) const;
    void pushScope();
    void popScope();
    [[nodiscard]] std::optional<VariableSymbol> findVariable(const std::string& name) const;

    Diagnostics& diagnostics_;
    std::unordered_map<std::string, Function*> functions_;
    std::vector<std::unordered_map<std::string, VariableSymbol>> scopes_;
    Function* currentFunction_ = nullptr;
};

} // namespace zlang
